import 'package:flutter/material.dart';
import 'package:animator/animator.dart';
import 'package:delayed_display/delayed_display.dart';
import 'authentication/login.dart';
import 'class_builder.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'sideBar.dart';

String email = '';
String name = '';
String method = '';
String image = '';

Future main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  final prefs = await SharedPreferences.getInstance();
  email = prefs.getString('deliverio_email');
  name = prefs.getString('deliverio_name');
  method = prefs.getString('deliverio_method');
  image = prefs.getString('deliverio_image');
  ClassBuilder.registerClasses();
  runApp(MyApp(status: name));
}

class MyApp extends StatelessWidget {

  var status;
  MyApp({this.status});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: status == null ? SplashScreen() : side_Bar(),
    );
  }
}

class SplashScreen extends StatefulWidget {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xff141615),
      body: Stack(
        children: [
          Animator<double>(
            tween: Tween<double>(begin: 0, end: 300),
            cycles: 1,
            builder: (context, animatorState, child ) => Center(
              child: Container(
                margin: EdgeInsets.symmetric(vertical: 10),
                height: animatorState.value,
                width: animatorState.value,
                child: Image(image: AssetImage('images/logo.jpeg')),
              ),
            ),
          ),
          DelayedDisplay(
            delay: Duration(seconds: 2),
            child: loginPage(),//advertisementPage(),
          ),
        ],
      ),
    );
  }
}
