package com.example.deliverio

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
